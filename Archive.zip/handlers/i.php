<?php 
    // Configuration
    $hostname = "localhost";
    $username = "sean_smorrow";
    $password = "keppeL123";
    $database = "sean_smorrow";
?>